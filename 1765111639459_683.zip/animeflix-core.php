<?php
/**
 * Plugin Name: Animeflix Core
 * Description: Adds the "Anime Shows" menu and installs Demo Data.
 * Version: 5.0
 * Author: Animeflix
 */

if (!defined('ABSPATH')) exit;

// 1. REGISTER CONTENT TYPE
function af_register_cpt() {
    register_post_type('anime_show', [
        'labels' => [
            'name' => 'Anime Shows',
            'singular_name' => 'Anime Show',
            'add_new_item' => 'Add New Show',
            'edit_item' => 'Edit Show',
            'all_items' => 'All Shows',
        ],
        'public' => true,
        'menu_icon' => 'dashicons-video-alt3',
        'supports' => ['title', 'thumbnail'], // Thumbnail is the Poster
        'has_archive' => false,
    ]);

    register_taxonomy('anime_cat', 'anime_show', [
        'labels' => ['name' => 'Categories'],
        'hierarchical' => true,
        'show_admin_column' => true,
    ]);
}
add_action('init', 'af_register_cpt');

// 2. CUSTOM FIELDS (Episodes, Links, etc)
function af_add_meta() { add_meta_box('af_info', 'Show Info', 'af_meta_html', 'anime_show', 'normal', 'high'); }
add_action('add_meta_boxes', 'af_add_meta');

function af_meta_html($post) {
    $eps = get_post_meta($post->ID, '_af_eps', true);
    $url = get_post_meta($post->ID, '_af_url', true);
    $hero = get_post_meta($post->ID, '_af_hero', true);
    $hero_img = get_post_meta($post->ID, '_af_hero_img', true);
    $tags = get_post_meta($post->ID, '_af_tags', true);
    ?>
    <style>
        .af-field { margin-bottom: 15px; }
        .af-field label { font-weight: bold; display: block; margin-bottom: 5px; }
        .af-field input { width: 100%; padding: 8px; border: 1px solid #ddd; }
    </style>
    <div class="af-field">
        <label>Subtitle / Episodes:</label>
        <input type="text" name="af_eps" value="<?php echo esc_attr($eps); ?>" placeholder="e.g. 24 Episodes • Action">
    </div>
    <div class="af-field">
        <label>Video Link (URL):</label>
        <input type="text" name="af_url" value="<?php echo esc_attr($url); ?>" placeholder="https://...">
    </div>
    <div class="af-field">
        <label>
            <input type="checkbox" name="af_hero" value="yes" <?php checked($hero, 'yes'); ?>> 
            <strong>Show in Big Hero Slider?</strong>
        </label>
    </div>
    <div class="af-field">
        <label>Hero Wide Image URL (Optional):</label>
        <input type="text" name="af_hero_img" value="<?php echo esc_attr($hero_img); ?>">
        <small>If empty, app uses the Poster image.</small>
    </div>
    <div class="af-field">
        <label>Tags (Comma separated):</label>
        <input type="text" name="af_tags" value="<?php echo esc_attr($tags); ?>" placeholder="Action, Drama, Fantasy">
    </div>
    <?php
}

function af_save_meta($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (isset($_POST['af_eps'])) update_post_meta($post_id, '_af_eps', sanitize_text_field($_POST['af_eps']));
    if (isset($_POST['af_url'])) update_post_meta($post_id, '_af_url', esc_url_raw($_POST['af_url']));
    update_post_meta($post_id, '_af_hero', isset($_POST['af_hero']) ? 'yes' : 'no');
    if (isset($_POST['af_hero_img'])) update_post_meta($post_id, '_af_hero_img', esc_url_raw($_POST['af_hero_img']));
    if (isset($_POST['af_tags'])) update_post_meta($post_id, '_af_tags', sanitize_text_field($_POST['af_tags']));
}
add_action('save_post', 'af_save_meta');

// 3. INSTALL DEMO DATA (Runs once on activation)
register_activation_hook(__FILE__, 'af_demo_data');
function af_demo_data() {
    if (get_posts(['post_type'=>'anime_show','numberposts'=>1])) return; // Don't run if data exists

    $cats = ['🔥 Trending Now' => [], '📺 Ongoing Anime' => [], '🇮🇳 Hindi Dubbed' => []];
    foreach(array_keys($cats) as $c) wp_insert_term($c, 'anime_cat');

    $shows = [
        ['title'=>'Jujutsu Kaisen 0', 'cat'=>'🔥 Trending Now', 'hero'=>'yes', 'img'=>'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0', 'eps'=>'Movie • Action', 'tags'=>'Movie, Action'],
        ['title'=>'Nature\'s Wrath', 'cat'=>'🔥 Trending Now', 'hero'=>'yes', 'img'=>'https://images.unsplash.com/photo-1541562232579-512a21360020', 'eps'=>'12 Eps • Fantasy', 'tags'=>'Fantasy, Drama'],
        ['title'=>'Solo Leveling', 'cat'=>'🇮🇳 Hindi Dubbed', 'hero'=>'no', 'img'=>'https://images.unsplash.com/photo-1519074069444-1ba4fff66d16', 'eps'=>'12 Eps • Action', 'tags'=>'Action'],
        ['title'=>'Demon Slayer', 'cat'=>'📺 Ongoing Anime', 'hero'=>'no', 'img'=>'https://images.unsplash.com/photo-1578632767115-351597cf2477', 'eps'=>'Ongoing', 'tags'=>'Shonen']
    ];

    foreach($shows as $s) {
        $id = wp_insert_post(['post_title'=>$s['title'], 'post_type'=>'anime_show', 'post_status'=>'publish']);
        $term = get_term_by('name', $s['cat'], 'anime_cat');
        wp_set_object_terms($id, $term->term_id, 'anime_cat');
        update_post_meta($id, '_af_eps', $s['eps']);
        update_post_meta($id, '_af_hero', $s['hero']);
        update_post_meta($id, '_af_hero_img', $s['img']); 
        update_post_meta($id, '_af_tags', $s['tags']); 
        update_post_meta($id, '_af_url', '#');
    }
}